<?php
$a = 20;
$b = 10;
$c= $a+$b;
echo "The sum of two numbers is $c";
echo "<br/>";
$c= $a-$b;
echo "The difference of two numbers is $c";
echo "<br/>";
$c= $a*$b;
echo "The product of two numbers is $c";
echo "<br/>";
$c=$a/$b;
echo "The divison of two numbers is $c";
echo "<br/>";
?>
