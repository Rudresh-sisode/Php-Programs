<?php
$string1 = 'Concatenate ';
$string2 = 'this strings ';
$string3 = 'using dot operator';
$result = $string1.$string2.$string3;
echo $result;
?>